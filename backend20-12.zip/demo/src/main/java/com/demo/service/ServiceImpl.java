package com.demo.service;


import com.demo.entity.loginTable;






public interface ServiceImpl {

	public String Login(loginTable login);

	//public String Login(login login);
	

}
