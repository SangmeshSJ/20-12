import { Rating } from './rating';


export const Rate:Rating[]=[
   
    {    value: '1',
        name:'Not Applicable ',
    
     },
     
        
    {    value: '2',
        name:'Inadequate / Not Relevant',
    
      },
      
         
    {    value:'3' ,
        name:'Adequate / Reasonably Relevant',
    
       },
       
          
    {    value: '4',
        name:'Good / Relevant',
    
        },
              
    {    value: '5',
    name:'Excellent / Very Relevant">Excellent / Very Relevant',

    },
          
    {    value: '6',
        name:'Outstanding / Ideal fitment">Outstanding / Ideal fitment',
    
        },
];