export class Skill{
    skillId: Number;
    skillName:String;
}